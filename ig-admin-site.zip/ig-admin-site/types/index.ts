export type Category = {
  id: string;
  name: string;
  slug: string;
};

export type PortfolioMedia = {
  id: string;
  portfolioId: string;
  type: "image" | "video" | "embed";
  url: string;
  thumbnail: string | null;
  sortOrder: number;
};

export type PortfolioItem = {
  id: string;
  title: string;
  slug: string;
  categoryId: string;
  categoryName: string;
  categorySlug: string;
  clientName: string | null;
  description: string;
  coverImage: string;
  beforeImage: string | null;
  afterImage: string | null;
  problem: string | null;
  workDone: string[];
  strategy: string | null;
  tags: string[];
  results: string | null;
  featured: boolean;
  published: boolean;
  isDemo?: boolean;
  createdAt: string;
};

export type Service = {
  id: string;
  title: string;
  description: string;
  icon: string;
  sortOrder: number;
  active: boolean;
};

export type Testimonial = {
  id: string;
  clientName: string;
  business: string;
  content: string;
  avatar: string | null;
  published: boolean;
};

export type Faq = {
  id: string;
  question: string;
  answer: string;
  sortOrder: number;
};

export type LeadStatus = "جدید" | "در حال پیگیری" | "تکمیل شد" | "رد شد";

export type Lead = {
  id: string;
  name: string;
  phone: string;
  businessType: string;
  instagramUsername: string | null;
  service: string;
  message: string | null;
  status: LeadStatus;
  createdAt: string;
};

export type SiteSettings = {
  whatsappNumber: string;
  instagramUrl: string;
  heroTitle: string;
  heroSubtitle: string;
  statsProjects: string | null;
  statsContent: string | null;
  statsPages: string | null;
  statsYears: string | null;
};
