import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { signOutAction } from "@/app/admin/actions";

const ADMIN_NAV = [
  { label: "نمای کلی", href: "/admin" },
  { label: "لیدها", href: "/admin/leads" },
  { label: "پورتفولیو", href: "/admin/portfolio" },
  { label: "تنظیمات", href: "/admin/settings" },
];

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // middleware.ts همین چک رو می‌کنه، ولی این لایه دومه — اگه یک‌روزی
  // matcher میدل‌ور عوض/باگ‌دار بشه، اینجا همچنان جلوی دسترسی بدون لاگین رو می‌گیره.
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/admin/login");

  return (
    <div className="min-h-screen bg-paper" dir="rtl">
      <header className="flex items-center justify-between border-b border-line/60 px-6 py-4">
        <nav className="flex items-center gap-6">
          <span className="font-bold">پنل مدیریت</span>
          {ADMIN_NAV.map((item) => (
            <Link key={item.href} href={item.href} className="text-sm text-ink/70 hover:text-ink">
              {item.label}
            </Link>
          ))}
        </nav>

        <form action={signOutAction}>
          <button type="submit" className="text-sm text-ink/60 hover:text-ink">
            خروج
          </button>
        </form>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-10">{children}</main>
    </div>
  );
}
