import { getCategories } from "@/lib/data/categories";
import { PortfolioForm } from "@/components/admin/portfolio-form";

export default async function NewPortfolioPage() {
  const categories = await getCategories();

  return (
    <div>
      <h1 className="text-2xl font-bold">پروژه جدید</h1>
      <div className="mt-6">
        <PortfolioForm categories={categories} />
      </div>
    </div>
  );
}
