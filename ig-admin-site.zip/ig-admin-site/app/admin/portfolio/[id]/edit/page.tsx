import { notFound } from "next/navigation";
import { getCategories } from "@/lib/data/categories";
import { getPortfolioByIdAdmin } from "@/lib/data/portfolio";
import { PortfolioForm } from "@/components/admin/portfolio-form";

export default async function EditPortfolioPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const [categories, item] = await Promise.all([getCategories(), getPortfolioByIdAdmin(id)]);

  if (!item) notFound();

  return (
    <div>
      <h1 className="text-2xl font-bold">ویرایش پروژه</h1>
      <div className="mt-6">
        <PortfolioForm categories={categories} initial={item} />
      </div>
    </div>
  );
}
