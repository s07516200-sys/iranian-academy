import Link from "next/link";
import { getAllPortfolioAdmin } from "@/lib/data/portfolio";
import { DeletePortfolioButton } from "@/components/admin/delete-portfolio-button";

export default async function AdminPortfolioPage() {
  const items = await getAllPortfolioAdmin();

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">پورتفولیو</h1>
        <Link
          href="/admin/portfolio/new"
          className="rounded-full bg-ink px-4 py-2 text-sm text-paper hover:bg-line"
        >
          + پروژه جدید
        </Link>
      </div>

      {items.length === 0 ? (
        <p className="mt-8 text-sm text-muted">هنوز پروژه‌ای ثبت نشده.</p>
      ) : (
        <div className="mt-6 overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b border-line/60 text-start text-muted">
                <th className="py-2 pe-4 font-normal">عنوان</th>
                <th className="py-2 pe-4 font-normal">دسته</th>
                <th className="py-2 pe-4 font-normal">وضعیت</th>
                <th className="py-2 font-normal"></th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id} className="border-b border-line/30">
                  <td className="py-3 pe-4">{item.title}</td>
                  <td className="py-3 pe-4 text-muted">{item.categoryName}</td>
                  <td className="py-3 pe-4">
                    <span
                      className={
                        item.published
                          ? "rounded-full bg-moss/20 px-2 py-0.5 text-xs text-moss"
                          : "rounded-full bg-line/30 px-2 py-0.5 text-xs text-muted"
                      }
                    >
                      {item.published ? "منتشرشده" : "پیش‌نویس"}
                    </span>
                    {item.featured && (
                      <span className="ms-2 rounded-full bg-gold/20 px-2 py-0.5 text-xs text-gold">
                        ویژه
                      </span>
                    )}
                  </td>
                  <td className="py-3">
                    <div className="flex items-center gap-3">
                      <Link
                        href={`/admin/portfolio/${item.id}/edit`}
                        className="text-xs text-gold hover:underline"
                      >
                        ویرایش
                      </Link>
                      <DeletePortfolioButton id={item.id} title={item.title} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
