import Link from "next/link";
import { getLeadCounts } from "@/lib/data/leads";

export default async function AdminOverviewPage() {
  const counts = await getLeadCounts();
  const total = Object.values(counts).reduce((a, b) => a + b, 0);

  return (
    <div>
      <h1 className="text-2xl font-bold">نمای کلی</h1>

      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatCard label="کل لیدها" value={total} />
        <StatCard label="جدید" value={counts["جدید"]} highlight />
        <StatCard label="در حال پیگیری" value={counts["در حال پیگیری"]} />
        <StatCard label="تکمیل شد" value={counts["تکمیل شد"]} />
      </div>

      <div className="mt-8">
        <Link href="/admin/leads" className="text-sm text-gold underline">
          مشاهده همه لیدها
        </Link>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  highlight = false,
}: {
  label: string;
  value: number;
  highlight?: boolean;
}) {
  return (
    <div
      className={`rounded-card border p-5 ${
        highlight ? "border-gold bg-gold/10" : "border-line/60"
      }`}
    >
      <p className="text-3xl font-extrabold">{value}</p>
      <p className="mt-1 text-sm text-muted">{label}</p>
    </div>
  );
}
