import { getSiteSettings } from "@/lib/data/settings";
import { updateSettingsAction } from "@/app/admin/actions";

export default async function AdminSettingsPage() {
  const settings = await getSiteSettings();

  return (
    <div>
      <h1 className="text-2xl font-bold">تنظیمات سایت</h1>

      <form action={updateSettingsAction} className="mt-6 max-w-xl space-y-5">
        <Field label="شماره واتساپ" hint="بدون + و صفر ابتدایی، مثال: 989121234567">
          <input
            name="whatsappNumber"
            defaultValue={settings.whatsappNumber}
            className="input"
            dir="ltr"
          />
        </Field>

        <Field label="لینک اینستاگرام">
          <input
            name="instagramUrl"
            defaultValue={settings.instagramUrl}
            className="input"
            dir="ltr"
          />
        </Field>

        <Field label="عنوان هیرو (صفحه اصلی)">
          <input name="heroTitle" defaultValue={settings.heroTitle} className="input" />
        </Field>

        <Field label="زیرعنوان هیرو">
          <textarea
            name="heroSubtitle"
            defaultValue={settings.heroSubtitle}
            rows={2}
            className="input resize-none"
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="تعداد پروژه" hint="خالی = نمایش داده نشه">
            <input name="statsProjects" defaultValue={settings.statsProjects ?? ""} className="input" />
          </Field>
          <Field label="تعداد محتوای تولیدشده">
            <input name="statsContent" defaultValue={settings.statsContent ?? ""} className="input" />
          </Field>
          <Field label="تعداد پیج مدیریت‌شده">
            <input name="statsPages" defaultValue={settings.statsPages ?? ""} className="input" />
          </Field>
          <Field label="سال تجربه">
            <input name="statsYears" defaultValue={settings.statsYears ?? ""} className="input" />
          </Field>
        </div>

        <p className="text-xs text-muted">
          فقط آماری که اینجا واقعاً وارد کنی روی صفحه اصلی نشون داده می‌شه — چیزی ساختگی درج نمی‌شه.
        </p>

        <button
          type="submit"
          className="rounded-full bg-ink px-6 py-3 text-sm font-medium text-paper hover:bg-line"
        >
          ذخیره تنظیمات
        </button>
      </form>
    </div>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm text-ink/70">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}
