"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import {
  createPortfolioItem,
  updatePortfolioItem,
  deletePortfolioItem,
} from "@/lib/data/portfolio";
import { updateSiteSettings } from "@/lib/data/settings";
import {
  portfolioFormSchema,
  linesToArray,
  commaToArray,
} from "@/lib/validations/portfolio";
import type { LeadStatus, SiteSettings } from "@/types";

async function requireAdmin() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("دسترسی غیرمجاز");
}

export async function signOutAction() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/admin/login");
}

const VALID_STATUSES: LeadStatus[] = ["جدید", "در حال پیگیری", "تکمیل شد", "رد شد"];

export async function updateLeadStatusAction(leadId: string, status: string) {
  // بررسی صریح ورودی — چون این تابع از یک <form> صدا زده می‌شه و
  // status از یک select میاد، ولی هیچ‌وقت نباید به مقدار خام کلاینت اعتماد کرد.
  if (!VALID_STATUSES.includes(status as LeadStatus)) {
    throw new Error("وضعیت نامعتبر");
  }

  await requireAdmin();

  const admin = createAdminClient();
  const { error } = await admin
    .from("leads")
    .update({ status })
    .eq("id", leadId);

  if (error) throw new Error(error.message);

  revalidatePath("/admin/leads");
  revalidatePath("/admin");
}

export async function savePortfolioAction(formData: FormData) {
  await requireAdmin();

  const raw = {
    title: String(formData.get("title") ?? ""),
    slug: String(formData.get("slug") ?? ""),
    categoryId: String(formData.get("categoryId") ?? ""),
    clientName: String(formData.get("clientName") ?? ""),
    description: String(formData.get("description") ?? ""),
    problem: String(formData.get("problem") ?? ""),
    workDoneText: String(formData.get("workDoneText") ?? ""),
    strategy: String(formData.get("strategy") ?? ""),
    tagsText: String(formData.get("tagsText") ?? ""),
    coverImage: String(formData.get("coverImage") ?? ""),
    beforeImage: String(formData.get("beforeImage") ?? ""),
    afterImage: String(formData.get("afterImage") ?? ""),
    results: String(formData.get("results") ?? ""),
    // چک‌باکس‌ها وقتی تیک‌نخورده باشن اصلاً در FormData نمی‌آن، نه "false"
    featured: formData.get("featured") === "on",
    published: formData.get("published") === "on",
  };

  const parsed = portfolioFormSchema.safeParse(raw);
  if (!parsed.success) {
    throw new Error(parsed.error.issues[0]?.message ?? "اطلاعات نامعتبر است.");
  }

  const input = {
    title: parsed.data.title,
    slug: parsed.data.slug,
    categoryId: parsed.data.categoryId,
    clientName: parsed.data.clientName ?? "",
    description: parsed.data.description,
    problem: parsed.data.problem ?? "",
    workDone: linesToArray(parsed.data.workDoneText),
    strategy: parsed.data.strategy ?? "",
    tags: commaToArray(parsed.data.tagsText),
    coverImage: parsed.data.coverImage ?? "",
    beforeImage: parsed.data.beforeImage ?? "",
    afterImage: parsed.data.afterImage ?? "",
    results: parsed.data.results ?? "",
    featured: parsed.data.featured,
    published: parsed.data.published,
  };

  const id = formData.get("id");

  if (id && typeof id === "string" && id.length > 0) {
    await updatePortfolioItem(id, input);
  } else {
    await createPortfolioItem(input);
  }

  revalidatePath("/admin/portfolio");
  revalidatePath("/portfolio");
  revalidatePath("/");
  // عمداً redirect() اینجا صدا زده نمی‌شه: این action از یک تابع کلاینتی
  // با try/catch صدا زده می‌شه (نه مستقیم به عنوان form action)، و redirect()
  // با throw کار می‌کنه — همون throw توسط catch گرفته می‌شد و به اشتباه
  // «ذخیره نشد» نشون می‌داد. ریدایرکت رو خود فرم بعد از موفقیت انجام می‌ده.
}

export async function deletePortfolioAction(id: string) {
  await requireAdmin();
  await deletePortfolioItem(id);
  revalidatePath("/admin/portfolio");
  revalidatePath("/portfolio");
  revalidatePath("/");
}

export async function updateSettingsAction(formData: FormData) {
  await requireAdmin();

  const partial: Partial<SiteSettings> = {
    whatsappNumber: String(formData.get("whatsappNumber") ?? "").trim(),
    instagramUrl: String(formData.get("instagramUrl") ?? "").trim(),
    heroTitle: String(formData.get("heroTitle") ?? "").trim(),
    heroSubtitle: String(formData.get("heroSubtitle") ?? "").trim(),
    statsProjects: String(formData.get("statsProjects") ?? "").trim() || null,
    statsContent: String(formData.get("statsContent") ?? "").trim() || null,
    statsPages: String(formData.get("statsPages") ?? "").trim() || null,
    statsYears: String(formData.get("statsYears") ?? "").trim() || null,
  };

  await updateSiteSettings(partial);

  revalidatePath("/admin/settings");
  revalidatePath("/");
}
