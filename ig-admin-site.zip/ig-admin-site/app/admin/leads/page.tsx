import { getLeads } from "@/lib/data/leads";
import { LeadsTable } from "@/components/admin/leads-table";

export default async function AdminLeadsPage() {
  const leads = await getLeads();

  return (
    <div>
      <h1 className="text-2xl font-bold">لیدها</h1>
      <p className="mt-1 text-sm text-muted">{leads.length} لید ثبت‌شده</p>

      <div className="mt-6">
        <LeadsTable leads={leads} />
      </div>
    </div>
  );
}
