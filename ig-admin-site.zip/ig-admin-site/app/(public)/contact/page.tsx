import type { Metadata } from "next";
import { ContactCta } from "@/components/sections/contact-cta";

export const metadata: Metadata = {
  title: "تماس با من",
  description: "درخواست مشاوره برای مدیریت حرفه‌ای پیج اینستاگرام کسب‌وکار شما.",
};

export default function ContactPage() {
  return <ContactCta headingLevel="h1" />;
}
