import { Hero } from "@/components/sections/hero";
import { QuickStats } from "@/components/sections/quick-stats";
import { Services } from "@/components/sections/services";
import { PortfolioPreview } from "@/components/sections/portfolio-preview";
import { WhyMe } from "@/components/sections/why-me";
import { Process } from "@/components/sections/process";
import { Faq } from "@/components/sections/faq";
import { ContactCta } from "@/components/sections/contact-cta";
import { getFeaturedItems } from "@/lib/data/portfolio";
import { getSiteSettings } from "@/lib/data/settings";

export default async function HomePage() {
  const [featured, settings] = await Promise.all([
    getFeaturedItems(3),
    getSiteSettings(),
  ]);

  return (
    <>
      <Hero settings={settings} />
      <QuickStats settings={settings} />
      <Services />
      <PortfolioPreview items={featured} />
      <WhyMe />
      <Process />
      <Faq />
      <ContactCta />
    </>
  );
}
