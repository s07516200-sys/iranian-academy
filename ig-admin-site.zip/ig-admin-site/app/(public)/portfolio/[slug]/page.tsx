import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { DEMO_SLUG, getPortfolioItemBySlug, getPublishedSlugs } from "@/lib/data/portfolio";
import { CaseStudy } from "@/components/sections/case-study";

export async function generateStaticParams() {
  // نمونهٔ قالب هم اینجا build می‌شه تا قابل پیش‌نمایش باشه، ولی noindex داره (پایین)
  // و هیچ لینکی از UI عمومی بهش اشاره نمی‌کنه.
  const slugs = await getPublishedSlugs();
  return [{ slug: DEMO_SLUG }, ...slugs.map((slug) => ({ slug }))];
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const item = await getPortfolioItemBySlug(slug);
  if (!item) return {};

  return {
    title: item.title,
    description: item.description,
    robots: item.isDemo || !item.published ? { index: false } : undefined,
  };
}

export default async function PortfolioDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const item = await getPortfolioItemBySlug(slug);

  // فقط پروژه‌های published (یا نمونهٔ قالب) قابل نمایشن
  if (!item || (!item.published && !item.isDemo)) notFound();

  return <CaseStudy item={item} />;
}
