export default function LoadingPortfolio() {
  return (
    <div className="section">
      <div className="h-4 w-20 animate-pulse rounded bg-line/30" />
      <div className="mt-3 h-10 w-72 animate-pulse rounded bg-line/30" />

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="rounded-card border border-line/60 p-5">
            <div className="aspect-video animate-pulse rounded-sm bg-line/20" />
            <div className="mt-4 h-4 w-2/3 animate-pulse rounded bg-line/20" />
            <div className="mt-2 h-3 w-full animate-pulse rounded bg-line/10" />
          </div>
        ))}
      </div>
    </div>
  );
}
