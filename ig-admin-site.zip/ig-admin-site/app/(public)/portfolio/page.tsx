import type { Metadata } from "next";
import { PortfolioGrid } from "@/components/sections/portfolio-grid";
import { getPublishedItems } from "@/lib/data/portfolio";
import { getCategories } from "@/lib/data/categories";

export const metadata: Metadata = {
  title: "نمونه‌کارها",
  description: "نمونه پروژه‌های مدیریت و رشد پیج اینستاگرام.",
};

export const revalidate = 60;

export default async function PortfolioPage() {
  const [items, categories] = await Promise.all([getPublishedItems(), getCategories()]);

  return (
    <div className="section">
      <p className="eyebrow">نمونه‌کارها</p>
      <h1 className="mt-2 text-4xl font-extrabold">پروژه‌هایی که انجام دادم</h1>

      <PortfolioGrid items={items} categories={categories} />
    </div>
  );
}
