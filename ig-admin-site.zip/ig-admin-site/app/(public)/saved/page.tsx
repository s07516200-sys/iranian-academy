import type { Metadata } from "next";
import { SavedList } from "@/components/sections/saved-list";
import { getPublishedItems } from "@/lib/data/portfolio";

// صفحه شخصی هر کاربره (بر اساس localStorage محلی)، محتوای یکسانی برای ایندکس نداره.
export const metadata: Metadata = {
  title: "پروژه‌های ذخیره‌شده",
  robots: { index: false },
};

export default async function SavedPage() {
  const items = await getPublishedItems();
  return <SavedList allItems={items} />;
}
