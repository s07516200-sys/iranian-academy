import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "درباره من",
  description: "آشنایی با ادمین و مدیر اینستاگرام و تخصص‌ها.",
};

// همه فیلدهای این صفحه در فاز ۶ از پنل ادمین ویرایش می‌شن؛
// مقادیر فعلی placeholder‌اند و باید با اطلاعات واقعی جایگزین بشن.
export default function AboutPage() {
  return (
    <div className="section max-w-2xl">
      <p className="eyebrow">درباره من</p>
      <h1 className="mt-2 text-4xl font-extrabold">سعید</h1>
      <p className="mt-1 text-ink/60">ادمین و مدیر اینستاگرام</p>

      <div className="mt-8 space-y-6 text-sm leading-7 text-ink/70">
        <p>[توضیح کوتاه درباره خودت، سابقه کاری و علاقه‌ات به این حوزه — از پنل ادمین قابل ویرایش]</p>

        <div>
          <h2 className="mb-2 text-base font-semibold text-ink">تخصص</h2>
          <p>[حوزه‌های تخصصی، مثلاً: رستوران و کافه، فروشگاه آنلاین، خدمات محلی]</p>
        </div>

        <div>
          <h2 className="mb-2 text-base font-semibold text-ink">مهارت‌ها</h2>
          <p>[مهارت‌های ابزاری و تخصصی — مثلاً: تدوین ویدیو، طراحی گرافیک، تحلیل داده]</p>
        </div>
      </div>
    </div>
  );
}
