import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { WhatsappFloat } from "@/components/layout/whatsapp-float";
import { PersonJsonLd } from "@/components/seo/json-ld";
import { getSiteSettings } from "@/lib/data/settings";

export default async function PublicLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const settings = await getSiteSettings();

  return (
    <>
      <PersonJsonLd settings={settings} />
      <Header />
      <main>{children}</main>
      <Footer settings={settings} />
      <WhatsappFloat settings={settings} />
    </>
  );
}
