import type { Metadata } from "next";
import { Services } from "@/components/sections/services";
import { ContactCta } from "@/components/sections/contact-cta";

export const metadata: Metadata = {
  title: "خدمات",
  description:
    "خدمات ادمینی اینستاگرام: مدیریت پیج، تولید محتوا، تدوین ریلز، طراحی پست و استوری و استراتژی رشد.",
};

export default function ServicesPage() {
  return (
    <>
      <div className="section pb-0">
        <p className="eyebrow">خدمات</p>
        <h1 className="mt-2 text-4xl font-extrabold">
          هر آنچه پیجت برای رشد لازم داره
        </h1>
      </div>
      <Services full />
      <ContactCta />
    </>
  );
}
