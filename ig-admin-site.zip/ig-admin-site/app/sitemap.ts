import type { MetadataRoute } from "next";
import { SITE } from "@/lib/constants";
import { getPublishedSlugs } from "@/lib/data/portfolio";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticRoutes = ["", "/services", "/portfolio", "/about", "/contact"];
  const slugs = await getPublishedSlugs();

  return [
    ...staticRoutes.map((route) => ({
      url: `${SITE.url}${route}`,
      lastModified: new Date(),
    })),
    ...slugs.map((slug) => ({
      url: `${SITE.url}/portfolio/${slug}`,
      lastModified: new Date(),
    })),
  ];
}
