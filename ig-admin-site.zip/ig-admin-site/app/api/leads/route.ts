import { NextRequest, NextResponse } from "next/server";
import { leadSchema } from "@/lib/validations/lead";
import { createClient } from "@/lib/supabase/server";

// rate-limit ساده در حافظه — برای پروداکشن روی Vercel با ترافیک بالا
// باید به Upstash Redis یا مشابه مهاجرت کنه (چون سرورلس stateless هست).
const attempts = new Map<string, number[]>();
const WINDOW_MS = 10 * 60 * 1000;
const MAX_REQUESTS = 5;

function isRateLimited(ip: string) {
  const now = Date.now();
  const timestamps = (attempts.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  timestamps.push(now);
  attempts.set(ip, timestamps);
  return timestamps.length > MAX_REQUESTS;
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";

  if (isRateLimited(ip)) {
    return NextResponse.json(
      { error: "تعداد درخواست‌ها بیش از حد مجاز است. کمی بعد دوباره تلاش کنید." },
      { status: 429 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = leadSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: "اطلاعات وارد شده معتبر نیست.", issues: parsed.error.flatten() },
      { status: 400 }
    );
  }

  // honeypot پر شده → احتمالاً بات؛ ساکت موفق برگردون تا بات متوجه فیلتر نشه،
  // ولی هیچ‌چیزی درج نمی‌کنیم
  if (parsed.data.website) {
    return NextResponse.json({ ok: true });
  }

  // اینجا عمداً از کلاینت anon استفاده می‌کنیم نه service-role:
  // policy جدول leads فقط insert عمومی رو مجاز کرده (schema.sql)،
  // پس نیازی به دور زدن RLS نیست — کمترین سطح دسترسی لازم.
  try {
    const supabase = await createClient();

    const { error } = await supabase.from("leads").insert({
      name: parsed.data.name,
      phone: parsed.data.phone,
      business_type: parsed.data.businessType,
      instagram_username: parsed.data.instagramUsername || null,
      service: parsed.data.service,
      message: parsed.data.message || null,
      status: "جدید",
    });

    if (error) {
      console.error("lead insert error:", error.message);
      return NextResponse.json(
        { error: "ثبت درخواست با مشکل مواجه شد. دوباره تلاش کن یا از واتساپ پیام بده." },
        { status: 500 }
      );
    }
  } catch (err) {
    // معمولاً یعنی NEXT_PUBLIC_SUPABASE_URL / ANON_KEY تنظیم نشده — راهنمای واضح در لاگ سرور
    console.error(
      "Supabase client error — آیا .env.local پر شده و supabase/schema.sql اجرا شده؟",
      err
    );
    return NextResponse.json(
      { error: "سرور فعلاً به دیتابیس وصل نیست. کمی بعد دوباره تلاش کن." },
      { status: 500 }
    );
  }

  return NextResponse.json({ ok: true });
}
