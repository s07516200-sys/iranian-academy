import type { Metadata } from "next";
import { Vazirmatn } from "next/font/google";
import { SITE } from "@/lib/constants";
import { StoreHydrator } from "@/components/providers/store-hydrator";
import "./globals.css";

const vazirmatn = Vazirmatn({
  subsets: ["arabic"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: {
    default: "سعید | ادمین اینستاگرام",
    template: "%s | سعید، ادمین اینستاگرام",
  },
  description:
    "ادمینی، تولید محتوا و مدیریت حرفه‌ای اینستاگرام برای کسب‌وکارهایی که می‌خوان بهتر دیده بشن و مشتری بیشتری جذب کنن.",
  openGraph: {
    type: "website",
    locale: "fa_IR",
    siteName: "سعید | ادمین اینستاگرام",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl" className={vazirmatn.variable}>
      <body className="font-sans">
        <StoreHydrator />
        {children}
      </body>
    </html>
  );
}
