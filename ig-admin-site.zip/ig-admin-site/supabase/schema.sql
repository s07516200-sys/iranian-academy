-- ============================================================
-- سایت شخصی ادمین اینستاگرام — اسکیمای پایه (فاز ۳)
-- اجرا: در Supabase → SQL Editor این فایل رو paste و Run کن
-- ============================================================

create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------
-- categories
-- ----------------------------------------------------------------
create table categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  sort_order int not null default 0
);

insert into categories (name, slug, sort_order) values
  ('رستوران', 'restaurant', 1),
  ('فروشگاهی', 'shop', 2),
  ('خدماتی', 'service', 3),
  ('شخصی', 'personal', 4),
  ('سایر', 'other', 5);

-- ----------------------------------------------------------------
-- portfolio_items
-- ----------------------------------------------------------------
create table portfolio_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  category_id uuid references categories(id) on delete set null,
  client_name text,
  description text not null default '',
  problem text,           -- مشکل اولیه
  work_done text[] default '{}', -- کاری که انجام شد؛ هر آیتم یک عنصر آرایه (نه یک بلوک متنی)
  strategy text,          -- استراتژی محتوا
  cover_image text,
  before_image text,
  after_image text,
  results text,           -- فقط از طریق ادمین، هرگز ساخته‌شده توسط سیستم
  tags text[] default '{}',
  featured boolean not null default false,
  published boolean not null default false,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index portfolio_items_published_idx on portfolio_items (published, featured);
create index portfolio_items_category_idx on portfolio_items (category_id);

-- ----------------------------------------------------------------
-- portfolio_media (گالری، ریلز به‌صورت لینک/embed، نه فایل آپلودی)
-- ----------------------------------------------------------------
create table portfolio_media (
  id uuid primary key default gen_random_uuid(),
  portfolio_id uuid not null references portfolio_items(id) on delete cascade,
  type text not null check (type in ('image', 'video', 'embed')),
  url text not null,
  thumbnail text,
  sort_order int not null default 0
);

create index portfolio_media_portfolio_idx on portfolio_media (portfolio_id, sort_order);

-- ----------------------------------------------------------------
-- services
-- ----------------------------------------------------------------
create table services (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null,
  icon text not null default 'grid',
  sort_order int not null default 0,
  active boolean not null default true
);

-- ----------------------------------------------------------------
-- testimonials (فقط واقعی — هرگز به‌صورت خودکار پر نمی‌شه)
-- ----------------------------------------------------------------
create table testimonials (
  id uuid primary key default gen_random_uuid(),
  client_name text not null,
  business text,
  content text not null,
  avatar text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------
-- faqs
-- ----------------------------------------------------------------
create table faqs (
  id uuid primary key default gen_random_uuid(),
  question text not null,
  answer text not null,
  sort_order int not null default 0
);

-- ----------------------------------------------------------------
-- leads
-- ----------------------------------------------------------------
create table leads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text not null,
  business_type text not null,
  instagram_username text,
  service text not null,
  message text,
  status text not null default 'جدید'
    check (status in ('جدید', 'در حال پیگیری', 'تکمیل شد', 'رد شد')),
  created_at timestamptz not null default now()
);

create index leads_status_idx on leads (status, created_at desc);

-- ----------------------------------------------------------------
-- saved_items (بوکمارک — فاز ۴)
-- ----------------------------------------------------------------
create table saved_items (
  id uuid primary key default gen_random_uuid(),
  portfolio_id uuid not null references portfolio_items(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  anonymous_id uuid,
  created_at timestamptz not null default now(),
  constraint saved_items_owner check (
    (user_id is not null and anonymous_id is null) or
    (user_id is null and anonymous_id is not null)
  )
);

create unique index saved_items_unique_user on saved_items (portfolio_id, user_id) where user_id is not null;
create unique index saved_items_unique_anon on saved_items (portfolio_id, anonymous_id) where anonymous_id is not null;

-- ----------------------------------------------------------------
-- site_settings (key/value ساده برای هدر/هیرو/واتساپ/اینستاگرام/آمار)
-- ----------------------------------------------------------------
create table site_settings (
  key text primary key,
  value text not null
);

insert into site_settings (key, value) values
  ('whatsapp_number', ''),
  ('instagram_url', ''),
  ('hero_title', 'پیج اینستاگرامت رو حرفه‌ای مدیریت کن'),
  ('hero_subtitle', 'ادمینی، تولید محتوا و مدیریت حرفه‌ای اینستاگرام برای کسب‌وکارهایی که می‌خوان بهتر دیده بشن و مشتری بیشتری جذب کنن.'),
  ('stats_projects', ''),
  ('stats_content', ''),
  ('stats_pages', ''),
  ('stats_years', '');

-- ============================================================
-- Row Level Security
-- خواندن عمومی فقط روی محتوای published؛ نوشتن فقط با service_role
-- (که فقط در Route Handler های سرور استفاده می‌شه، هرگز در کلاینت)
-- ============================================================

alter table categories enable row level security;
alter table portfolio_items enable row level security;
alter table portfolio_media enable row level security;
alter table services enable row level security;
alter table testimonials enable row level security;
alter table faqs enable row level security;
alter table leads enable row level security;
alter table saved_items enable row level security;
alter table site_settings enable row level security;

create policy "public read categories" on categories for select using (true);
create policy "public read site_settings" on site_settings for select using (true);
create policy "public read services" on services for select using (active = true);
create policy "public read faqs" on faqs for select using (true);

create policy "public read published portfolio" on portfolio_items
  for select using (published = true);

create policy "public read media of published portfolio" on portfolio_media
  for select using (
    exists (
      select 1 from portfolio_items p
      where p.id = portfolio_media.portfolio_id and p.published = true
    )
  );

create policy "public read published testimonials" on testimonials
  for select using (published = true);

-- leads: بدون سیاست select برای anon؛ درج مجازه (فرم عمومی)، خواندن فقط با service_role
create policy "public can submit leads" on leads
  for insert with check (true);

-- saved_items: کاربر anon فقط رکورد خودش رو می‌بینه/می‌سازه (بر اساس anonymous_id ارسالی از کلاینت)
create policy "anyone can insert saved item" on saved_items
  for insert with check (true);

create policy "read own saved items" on saved_items
  for select using (true); -- فیلتر واقعی در query سمت اپ با anonymous_id/user_id انجام می‌شه

-- نکته: هیچ policy برای update/delete تعریف نشده به‌جز از طریق service_role
-- (که RLS رو دور می‌زنه) — یعنی همه عملیات ادمین باید از Route Handler
-- با SUPABASE_SERVICE_ROLE_KEY انجام بشه، نه مستقیم از کلاینت مرورگر.
