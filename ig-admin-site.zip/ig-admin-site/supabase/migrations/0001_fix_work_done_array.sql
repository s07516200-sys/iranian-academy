-- فقط لازمه اگه قبلاً نسخه‌ی قدیمی schema.sql رو اجرا کرده باشی (وقتی
-- work_done هنوز از نوع text بوده، نه text[]). اگه تازه شروع می‌کنی و
-- هنوز schema.sql رو اجرا نکردی، این فایل رو نادیده بگیر — نسخه‌ی فعلی
-- schema.sql از اول درسته.
alter table portfolio_items
  alter column work_done type text[]
  using case
    when work_done is null or work_done = '' then '{}'::text[]
    else string_to_array(work_done, E'\n')
  end;

alter table portfolio_items
  alter column work_done set default '{}';
