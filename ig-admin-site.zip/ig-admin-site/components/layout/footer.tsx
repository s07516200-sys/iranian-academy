import Link from "next/link";
import { SITE, whatsappLink } from "@/lib/constants";
import type { SiteSettings } from "@/types";

export function Footer({ settings }: { settings: SiteSettings }) {
  return (
    <footer className="border-t border-line/60 bg-ink text-paper">
      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-14 sm:px-8 md:grid-cols-3">
        <div>
          <p className="text-lg font-bold">
            {SITE.brandName} <span className="text-gold">| {SITE.brandRole}</span>
          </p>
          <p className="mt-3 max-w-prose text-sm text-paper/70">
            مدیریت حرفه‌ای پیج اینستاگرام برای کسب‌وکارهایی که می‌خوان بهتر دیده بشن.
          </p>
        </div>

        <div>
          <p className="mb-3 text-sm text-paper/50">لینک‌ها</p>
          <ul className="space-y-2 text-sm">
            {SITE.nav.map((item) => (
              <li key={item.href}>
                <Link href={item.href} className="text-paper/80 hover:text-gold">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {(settings.whatsappNumber || settings.instagramUrl) && (
          <div>
            <p className="mb-3 text-sm text-paper/50">ارتباط</p>
            <ul className="space-y-2 text-sm">
              {settings.whatsappNumber && (
                <li>
                  <a
                    href={whatsappLink(settings.whatsappNumber)}
                    className="text-paper/80 hover:text-gold"
                  >
                    واتساپ
                  </a>
                </li>
              )}
              {settings.instagramUrl && (
                <li>
                  <a href={settings.instagramUrl} className="text-paper/80 hover:text-gold">
                    اینستاگرام
                  </a>
                </li>
              )}
            </ul>
          </div>
        )}
      </div>

      <div className="border-t border-paper/10 px-5 py-4 text-center text-xs text-paper/50 sm:px-8">
        © {new Date().getFullYear()} {SITE.brandName}. تمامی حقوق محفوظ است.
      </div>
    </footer>
  );
}
