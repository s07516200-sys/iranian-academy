"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, Heart } from "lucide-react";
import { SITE } from "@/lib/constants";
import { ButtonLink } from "@/components/ui/button";
import { useSavedStore } from "@/lib/store/saved";

export function Header() {
  const [open, setOpen] = useState(false);
  const hasHydrated = useSavedStore((s) => s.hasHydrated);
  const savedCount = useSavedStore((s) => s.savedIds.length);

  return (
    <header className="sticky top-0 z-50 border-b border-line/60 bg-paper/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 sm:px-8">
        <Link href="/" className="text-lg font-bold">
          {SITE.brandName}
          <span className="text-muted"> | {SITE.brandRole}</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {SITE.nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm text-ink/80 transition-colors hover:text-ink"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-4 md:flex">
          <Link
            href="/saved"
            aria-label="پروژه‌های ذخیره‌شده"
            className="relative text-ink/70 hover:text-ink"
          >
            <Heart size={20} />
            {hasHydrated && savedCount > 0 && (
              <span className="absolute -end-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-gold text-[10px] text-ink">
                {savedCount}
              </span>
            )}
          </Link>
          <ButtonLink href="/contact" variant="secondary">
            مشاوره و سفارش
          </ButtonLink>
        </div>

        <button
          className="md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "بستن منو" : "باز کردن منو"}
          aria-expanded={open}
          aria-controls="mobile-nav"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {open && (
        <nav id="mobile-nav" className="flex flex-col gap-1 border-t border-line/60 px-5 pb-4 md:hidden">
          {SITE.nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="py-3 text-ink/80"
              onClick={() => setOpen(false)}
            >
              {item.label}
            </Link>
          ))}
          <Link
            href="/saved"
            className="py-3 text-ink/80"
            onClick={() => setOpen(false)}
          >
            پروژه‌های ذخیره‌شده{hasHydrated && savedCount > 0 ? ` (${savedCount})` : ""}
          </Link>
          <ButtonLink href="/contact" variant="secondary" className="mt-2">
            مشاوره و سفارش
          </ButtonLink>
        </nav>
      )}
    </header>
  );
}
