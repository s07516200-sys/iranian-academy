import { whatsappLink } from "@/lib/constants";
import type { SiteSettings } from "@/types";

export function WhatsappFloat({ settings }: { settings: SiteSettings }) {
  // اگه شماره واتساپ هنوز از پنل ادمین تنظیم نشده، به‌جای لینک خراب چیزی نشون نمی‌دیم
  if (!settings.whatsappNumber) return null;

  return (
    <a
      href={whatsappLink(settings.whatsappNumber, "سلام، می‌خوام درباره ادمینی پیجم مشورت بگیرم.")}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-5 start-5 z-50 flex items-center gap-2 rounded-full bg-moss px-5 py-3 text-sm font-medium text-paper shadow-lg transition-transform hover:scale-105"
    >
      مشاوره در واتساپ
    </a>
  );
}
