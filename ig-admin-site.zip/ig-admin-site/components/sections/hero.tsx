import { ButtonLink } from "@/components/ui/button";
import type { SiteSettings } from "@/types";

export function Hero({ settings }: { settings: SiteSettings }) {
  return (
    <section className="section grid items-center gap-12 md:grid-cols-2">
      <div>
        <p className="eyebrow">مدیریت اینستاگرام کسب‌وکار شما</p>
        <h1 className="mt-3 text-4xl font-extrabold leading-tight sm:text-5xl">
          {settings.heroTitle}
        </h1>
        <p className="mt-5 max-w-prose text-base leading-8 text-ink/70">
          {settings.heroSubtitle}
        </p>

        <div className="mt-8 flex flex-wrap gap-3">
          <ButtonLink href="/contact" variant="primary">
            درخواست مشاوره
          </ButtonLink>
          <ButtonLink href="/portfolio" variant="ghost">
            مشاهده نمونه‌کارها
          </ButtonLink>
        </div>

        <ul className="mt-10 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted">
          <li>مدیریت پیج</li>
          <li>تولید محتوا</li>
          <li>طراحی ریلز</li>
          <li>استراتژی محتوا</li>
        </ul>
      </div>

      {/* پیش‌نمایش گرید اینستاگرام — به‌جای بج گرادیانی انتزاعی */}
      <div className="mx-auto w-full max-w-sm rounded-card border border-line/60 bg-white p-3 shadow-sm">
        <div className="mb-3 flex items-center gap-2 border-b border-line/40 pb-3">
          <div className="h-9 w-9 rounded-full bg-gold/30" />
          <div className="text-xs">
            <p className="font-semibold">your_business</p>
            <p className="text-muted">پیج مدیریت‌شده</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-1">
          {Array.from({ length: 9 }).map((_, i) => (
            <div
              key={i}
              className="aspect-square rounded-sm bg-gradient-to-br from-moss/20 to-gold/20"
            />
          ))}
        </div>
      </div>
    </section>
  );
}
