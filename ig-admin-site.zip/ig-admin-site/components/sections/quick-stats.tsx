import type { SiteSettings } from "@/types";

// فقط آماری که واقعاً از پنل ادمین (site_settings) ثبت شده نشون داده می‌شه —
// طبق دستور صریح: هیچ عدد ساختگی درج نشه.
export function QuickStats({ settings }: { settings: SiteSettings }) {
  const stats = [
    { value: settings.statsProjects, label: "پروژه" },
    { value: settings.statsContent, label: "محتوای تولیدشده" },
    { value: settings.statsPages, label: "پیج مدیریت‌شده" },
    { value: settings.statsYears, label: "سال تجربه" },
  ].filter((s) => s.value);

  if (stats.length === 0) {
    return (
      <section id="natayej" className="section py-10 text-center sm:py-14">
        <p className="text-sm text-muted">
          آمار عملکرد به‌زودی اینجا نمایش داده می‌شه.
        </p>
      </section>
    );
  }

  return (
    <section id="natayej" className="section py-10 sm:py-14">
      <div className="grid grid-cols-2 gap-6 border-y border-line/60 py-8 sm:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center">
            <p className="text-3xl font-extrabold text-ink">{stat.value}</p>
            <p className="mt-1 text-sm text-muted">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
