"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { leadSchema, type LeadInput } from "@/lib/validations/lead";
import { Button } from "@/components/ui/button";
import { SITE } from "@/lib/constants";

export function ContactCta({
  headingLevel = "h2",
}: {
  headingLevel?: "h1" | "h2";
} = {}) {
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">(
    "idle"
  );
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<LeadInput>({ resolver: zodResolver(leadSchema) });

  async function onSubmit(data: LeadInput) {
    setStatus("sending");
    setErrorMsg(null);
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json().catch(() => null);
      if (!res.ok) {
        setErrorMsg(result?.error ?? "ارسال با مشکل مواجه شد. دوباره تلاش کن.");
        setStatus("error");
        return;
      }
      setStatus("sent");
      reset();
    } catch {
      setErrorMsg("ارتباط با سرور برقرار نشد. اتصال اینترنت رو بررسی کن.");
      setStatus("error");
    }
  }

  if (status === "sent") {
    return (
      <section className="section max-w-xl text-center">
        <h2 className="text-2xl font-bold">درخواستت ثبت شد</h2>
        <p className="mt-3 text-ink/70">
          به‌زودی برای هماهنگی مشاوره باهات تماس می‌گیرم.
        </p>
      </section>
    );
  }

  return (
    <section id="contact" className="section max-w-xl">
      <p className="eyebrow">تماس با من</p>
      {headingLevel === "h1" ? (
        <h1 className="mt-2 text-3xl font-bold sm:text-4xl">درخواست مشاوره</h1>
      ) : (
        <h2 className="mt-2 text-3xl font-bold sm:text-4xl">درخواست مشاوره</h2>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="mt-8 space-y-4">
        {/* honeypot — از دید کاربر مخفیه */}
        <input
          type="text"
          {...register("website")}
          className="hidden"
          tabIndex={-1}
          autoComplete="off"
        />

        <Field label="نام" error={errors.name?.message}>
          <input {...register("name")} className="input" />
        </Field>

        <Field label="شماره تماس" error={errors.phone?.message}>
          <input {...register("phone")} className="input" placeholder="09121234567" />
        </Field>

        <Field label="نوع کسب‌وکار" error={errors.businessType?.message}>
          <input {...register("businessType")} className="input" />
        </Field>

        <Field label="آیدی اینستاگرام" error={errors.instagramUsername?.message}>
          <input {...register("instagramUsername")} className="input" placeholder="@username" />
        </Field>

        <Field label="نوع خدمات موردنیاز" error={errors.service?.message}>
          <select {...register("service")} className="input" defaultValue="">
            <option value="" disabled>
              انتخاب کن
            </option>
            {SITE.services.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
            <option value="نامشخص / نیاز به مشاوره">نامشخص / نیاز به مشاوره</option>
          </select>
        </Field>

        <Field label="توضیحات" error={errors.message?.message}>
          <textarea {...register("message")} rows={4} className="input resize-none" />
        </Field>

        {status === "error" && (
          <p className="text-sm text-red-600">{errorMsg}</p>
        )}

        <Button type="submit" disabled={status === "sending"} className="w-full">
          {status === "sending" ? "در حال ارسال..." : "درخواست مشاوره"}
        </Button>
      </form>
    </section>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm text-ink/70">{label}</span>
      {children}
      {error && <span className="mt-1 block text-xs text-red-600">{error}</span>}
    </label>
  );
}
