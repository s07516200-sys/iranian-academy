import {
  LayoutGrid,
  PenSquare,
  Clapperboard,
  Image as ImageIcon,
  CalendarDays,
  TrendingUp,
  Heart,
  BarChart3,
  type LucideIcon,
} from "lucide-react";
import { SERVICES, type ServiceItem } from "@/lib/data/services";
import { ButtonLink } from "@/components/ui/button";

const ICONS: Record<ServiceItem["icon"], LucideIcon> = {
  grid: LayoutGrid,
  pen: PenSquare,
  clapper: Clapperboard,
  image: ImageIcon,
  calendar: CalendarDays,
  trend: TrendingUp,
  heart: Heart,
  chart: BarChart3,
};

export function Services({ full = false }: { full?: boolean }) {
  return (
    <section className="section">
      <p className="eyebrow">خدمات</p>
      <h2 className="mt-2 text-3xl font-bold sm:text-4xl">
        چه کاری برات انجام می‌دم
      </h2>

      <div className="mt-10 grid gap-px overflow-hidden rounded-card border border-line/60 bg-line/60 sm:grid-cols-2 lg:grid-cols-4">
        {SERVICES.map((service) => {
          const Icon = ICONS[service.icon];
          return (
            <div key={service.slug} className="bg-paper p-6">
              <Icon className="text-gold" size={22} strokeWidth={1.75} />
              <h3 className="mt-4 text-base font-semibold">{service.title}</h3>
              <p className="mt-2 text-sm leading-6 text-ink/60">
                {full ? service.longDesc : service.shortDesc}
              </p>
            </div>
          );
        })}
      </div>

      {!full && (
        <div className="mt-8">
          <ButtonLink href="/services" variant="ghost">
            مشاهده همه خدمات
          </ButtonLink>
        </div>
      )}
    </section>
  );
}
