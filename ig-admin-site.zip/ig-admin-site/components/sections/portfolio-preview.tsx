import Link from "next/link";
import type { PortfolioItem } from "@/types";
import { ButtonLink } from "@/components/ui/button";
import { SaveButton } from "@/components/sections/save-button";

// در فاز ۳ این props از Supabase (published + featured) پر می‌شه.
export function PortfolioPreview({ items = [] }: { items?: PortfolioItem[] }) {
  return (
    <section className="section">
      <div className="flex items-end justify-between gap-4">
        <div>
          <p className="eyebrow">نمونه‌کارها</p>
          <h2 className="mt-2 text-3xl font-bold sm:text-4xl">
            چند نمونه از پروژه‌ها
          </h2>
        </div>
        <ButtonLink href="/portfolio" variant="ghost" className="hidden sm:inline-flex">
          مشاهده همه
        </ButtonLink>
      </div>

      {items.length === 0 ? (
        <div className="mt-10 rounded-card border border-dashed border-line/70 p-12 text-center">
          <p className="text-ink/70">نمونه‌کارهای جدید به‌زودی اضافه می‌شوند.</p>
        </div>
      ) : (
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <Link
              key={item.id}
              href={`/portfolio/${item.slug}`}
              className="group relative rounded-card border border-line/60 p-5 transition-colors hover:border-ink"
            >
              <SaveButton portfolioId={item.id} />
              <div className="aspect-video rounded-sm bg-moss/10" />
              <h3 className="mt-4 font-semibold">{item.title}</h3>
              <p className="mt-1 line-clamp-2 text-sm text-ink/60">
                {item.description}
              </p>
            </Link>
          ))}
        </div>
      )}
    </section>
  );
}
