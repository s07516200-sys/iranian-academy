import Image from "next/image";
import type { PortfolioItem } from "@/types";
import { ButtonLink } from "@/components/ui/button";

export function CaseStudy({ item }: { item: PortfolioItem }) {
  return (
    <article className="section max-w-3xl">
      {item.isDemo && (
        <div className="mb-8 rounded-card border border-gold/60 bg-gold/10 p-4 text-sm text-ink/80">
          این صفحه یک <strong>نمونهٔ قالب</strong> برای پیش‌نمایش طراحی کیس‌استادیه و پروژه واقعی نیست.
        </div>
      )}

      <p className="eyebrow">{item.categoryName}</p>
      <h1 className="mt-2 text-3xl font-extrabold sm:text-4xl">{item.title}</h1>
      {item.clientName && (
        <p className="mt-1 text-sm text-muted">مشتری: {item.clientName}</p>
      )}
      <p className="mt-4 text-ink/70">{item.description}</p>

      {item.tags.length > 0 && (
        <ul className="mt-4 flex flex-wrap gap-2">
          {item.tags.map((tag) => (
            <li
              key={tag}
              className="rounded-full border border-line/60 px-3 py-1 text-xs text-ink/60"
            >
              {tag}
            </li>
          ))}
        </ul>
      )}

      {item.coverImage && (
        <div className="relative mt-8 aspect-video overflow-hidden rounded-card bg-line/10">
          <Image src={item.coverImage} alt={item.title} fill className="object-cover" />
        </div>
      )}

      {(item.beforeImage || item.afterImage) && (
        <div className="mt-8 grid grid-cols-2 gap-3">
          <div>
            <p className="mb-2 text-xs text-muted">قبل</p>
            <div className="relative aspect-square overflow-hidden rounded-card bg-line/20">
              {item.beforeImage && (
                <Image src={item.beforeImage} alt="قبل" fill className="object-cover" />
              )}
            </div>
          </div>
          <div>
            <p className="mb-2 text-xs text-muted">بعد</p>
            <div className="relative aspect-square overflow-hidden rounded-card bg-gold/20">
              {item.afterImage && (
                <Image src={item.afterImage} alt="بعد" fill className="object-cover" />
              )}
            </div>
          </div>
        </div>
      )}

      {item.problem && (
        <section className="mt-10">
          <h2 className="text-lg font-semibold">مشکل اولیه</h2>
          <p className="mt-2 text-sm leading-7 text-ink/70">{item.problem}</p>
        </section>
      )}

      {item.strategy && (
        <section className="mt-8">
          <h2 className="text-lg font-semibold">استراتژی محتوا</h2>
          <p className="mt-2 text-sm leading-7 text-ink/70">{item.strategy}</p>
        </section>
      )}

      {item.workDone.length > 0 && (
        <section className="mt-8">
          <h2 className="text-lg font-semibold">کاری که انجام شد</h2>
          <ul className="mt-2 list-inside list-disc space-y-1 text-sm leading-7 text-ink/70">
            {item.workDone.map((w) => (
              <li key={w}>{w}</li>
            ))}
          </ul>
        </section>
      )}

      <section className="mt-8">
        <h2 className="text-lg font-semibold">نتایج</h2>
        {item.results ? (
          <p className="mt-2 text-sm leading-7 text-ink/70">{item.results}</p>
        ) : (
          <p className="mt-2 text-sm text-muted">
            نتایج این پروژه به‌زودی ثبت می‌شه.
          </p>
        )}
      </section>

      <div className="mt-12 border-t border-line/60 pt-8">
        <ButtonLink href="/contact">می‌خوام نتیجه مشابه بگیرم</ButtonLink>
      </div>
    </article>
  );
}
