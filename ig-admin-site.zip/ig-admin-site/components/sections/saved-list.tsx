"use client";

import Link from "next/link";
import { useSavedStore } from "@/lib/store/saved";
import { SaveButton } from "@/components/sections/save-button";
import type { PortfolioItem } from "@/types";

// allItems سمت سرور (Server Component) fetch می‌شه و اینجا فقط بر اساس
// savedIds ذخیره‌شده در localStorage فیلتر می‌شه — چون getPublishedItems
// حالا یک query واقعیه (async) و نمی‌شه مستقیم از یک کلاینت کامپوننت صداش زد.
export function SavedList({ allItems }: { allItems: PortfolioItem[] }) {
  const hasHydrated = useSavedStore((s) => s.hasHydrated);
  const savedIds = useSavedStore((s) => s.savedIds);

  const items = allItems.filter((item) => savedIds.includes(item.id));

  if (!hasHydrated) {
    return <div className="section" />; // از mismatch هیدریشن سرور/کلاینت جلوگیری می‌کنه
  }

  if (items.length === 0) {
    return (
      <div className="section text-center">
        <h1 className="text-3xl font-bold">پروژه‌های ذخیره‌شده</h1>
        <p className="mt-4 text-ink/60">
          هنوز پروژه‌ای ذخیره نکردی. از صفحه نمونه‌کارها، آیتم‌های موردعلاقه‌ات رو ذخیره کن.
        </p>
        <Link href="/portfolio" className="mt-6 inline-block text-sm text-gold underline">
          مشاهده نمونه‌کارها
        </Link>
      </div>
    );
  }

  return (
    <div className="section">
      <h1 className="text-3xl font-bold">
        پروژه‌های ذخیره‌شده{" "}
        <span className="text-base font-normal text-muted">({items.length})</span>
      </h1>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => (
          <Link
            key={item.id}
            href={`/portfolio/${item.slug}`}
            className="group relative rounded-card border border-line/60 p-5 transition-colors hover:border-ink"
          >
            <SaveButton portfolioId={item.id} />
            <div className="aspect-video rounded-sm bg-moss/10" />
            <h3 className="mt-4 font-semibold">{item.title}</h3>
          </Link>
        ))}
      </div>
    </div>
  );
}
