"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { PortfolioItem, Category } from "@/types";
import { SaveButton } from "@/components/sections/save-button";

export function PortfolioGrid({
  items,
  categories,
}: {
  items: PortfolioItem[];
  categories: Category[];
}) {
  const [active, setActive] = useState("همه");
  const filters = ["همه", ...categories.map((c) => c.name)];

  const filtered = useMemo(() => {
    if (active === "همه") return items;
    return items.filter((item) => item.categoryName === active);
  }, [items, active]);

  return (
    <>
      <div className="mt-8 flex gap-2 overflow-x-auto pb-2">
        {filters.map((cat) => (
          <button
            key={cat}
            onClick={() => setActive(cat)}
            aria-pressed={active === cat}
            className={
              active === cat
                ? "shrink-0 rounded-full border border-ink bg-ink px-4 py-2 text-sm text-paper"
                : "shrink-0 rounded-full border border-line/70 px-4 py-2 text-sm text-ink/70 transition-colors hover:border-ink"
            }
          >
            {cat}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="mt-10 rounded-card border border-dashed border-line/70 p-16 text-center">
          <p className="text-ink/70">
            {items.length === 0
              ? "نمونه‌کارهای جدید به‌زودی اضافه می‌شوند."
              : "در این دسته هنوز پروژه‌ای ثبت نشده."}
          </p>
        </div>
      ) : (
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((item) => (
            <Link
              key={item.id}
              href={`/portfolio/${item.slug}`}
              className="group relative rounded-card border border-line/60 p-5 transition-colors hover:border-ink"
            >
              {/* دکمه سیو واقعی — optimistic، در localStorage ذخیره می‌شه */}
              <SaveButton portfolioId={item.id} />
              <div className="aspect-video rounded-sm bg-moss/10" />
              <p className="mt-4 text-xs text-muted">{item.categoryName}</p>
              <h3 className="mt-1 font-semibold">{item.title}</h3>
              <p className="mt-1 line-clamp-2 text-sm text-ink/60">{item.description}</p>
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
