"use client";

import { useSavedStore } from "@/lib/store/saved";

export function SaveButton({ portfolioId }: { portfolioId: string }) {
  const hasHydrated = useSavedStore((s) => s.hasHydrated);
  const saved = useSavedStore((s) => s.savedIds.includes(portfolioId));
  const toggle = useSavedStore((s) => s.toggle);

  return (
    <button
      type="button"
      onClick={(e) => {
        e.preventDefault();
        toggle(portfolioId);
      }}
      aria-label={saved ? "حذف از ذخیره‌شده‌ها" : "ذخیره پروژه"}
      aria-pressed={saved}
      // قبل از hydration چیزی رو saved نشون نمی‌دیم تا با HTML سرور یکی باشه
      className="absolute start-4 top-4 z-10 flex items-center gap-1 text-sm transition-colors"
    >
      <span className={saved && hasHydrated ? "text-gold" : "text-ink/50"}>
        {saved && hasHydrated ? "✓ ذخیره شد" : "♡ ذخیره"}
      </span>
    </button>
  );
}
