const steps = [
  { title: "آشنایی با کسب‌وکار", desc: "بررسی هدف، مخاطب و فضای برند شما." },
  { title: "بررسی و تحلیل پیج", desc: "تحلیل وضعیت فعلی پیج و نقاط قابل بهبود." },
  { title: "طراحی استراتژی و تولید محتوا", desc: "تدوین تقویم محتوایی و شروع تولید." },
  { title: "اجرا، تحلیل و بهینه‌سازی", desc: "انتشار منظم و بهینه‌سازی بر اساس نتایج." },
];

export function Process() {
  return (
    <section className="section">
      <p className="eyebrow">فرآیند همکاری</p>
      <h2 className="mt-2 text-3xl font-bold sm:text-4xl">
        از شروع تا نتیجه
      </h2>

      <ol className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((step, i) => (
          <li key={step.title} className="border-t-2 border-gold pt-4">
            <span className="text-sm text-muted">{i + 1}</span>
            <h3 className="mt-1 text-base font-semibold">{step.title}</h3>
            <p className="mt-2 text-sm leading-6 text-ink/60">{step.desc}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
