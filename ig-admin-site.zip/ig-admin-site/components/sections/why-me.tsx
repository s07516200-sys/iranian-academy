const points = [
  "استراتژی متناسب با کسب‌وکار",
  "تولید محتوای هدفمند",
  "تمرکز روی جذب مشتری",
  "گزارش‌گیری و تحلیل",
  "پاسخگویی منظم",
  "طراحی محتوای حرفه‌ای",
];

export function WhyMe() {
  return (
    <section className="section bg-ink text-paper rounded-card">
      <p className="eyebrow text-moss-soft">چرا من</p>
      <h2 className="mt-2 text-3xl font-bold sm:text-4xl">
        چرا ادمینی پیجت رو به من بسپری؟
      </h2>

      <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {points.map((point) => (
          <li key={point} className="border-e-2 border-gold pe-4 text-sm leading-7 text-paper/80">
            {point}
          </li>
        ))}
      </ul>
    </section>
  );
}
