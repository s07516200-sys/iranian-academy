const faqs = [
  {
    q: "هزینه ادمینی چقدر است؟",
    a: "هزینه بسته به حجم کار و نوع کسب‌وکار متفاوته. برای گرفتن قیمت دقیق، یک مشاوره کوتاه رزرو کن.",
  },
  {
    q: "ادمینی شامل چه خدماتی می‌شود؟",
    a: "بسته به پکیج انتخابی، شامل برنامه‌ریزی محتوا، تولید پست/استوری/ریلز، پاسخگویی و گزارش عملکرده.",
  },
  {
    q: "تولید محتوا هم انجام می‌دهید؟",
    a: "بله، طراحی پست، استوری و تدوین ریلز بخشی از خدمات هست.",
  },
  {
    q: "برای رستوران‌ها هم ادمینی انجام می‌دهید؟",
    a: "بله، تجربه کار با کسب‌وکارهای رستورانی و کافه‌ای رو دارم.",
  },
  {
    q: "چقدر طول می‌کشد نتیجه بگیریم؟",
    a: "نتیجه به عوامل زیادی مثل وضعیت فعلی پیج و بازار بستگی داره؛ معمولاً نتایج پایدار در چند ماه اول همکاری قابل مشاهده‌ست.",
  },
  {
    q: "آیا گزارش عملکرد ارائه می‌دهید؟",
    a: "بله، گزارش دوره‌ای شفاف از وضعیت پیج و محتوا ارائه می‌شه.",
  },
];

export function Faq() {
  return (
    <section className="section max-w-3xl">
      <p className="eyebrow">سؤالات متداول</p>
      <h2 className="mt-2 text-3xl font-bold sm:text-4xl">قبل از شروع بخون</h2>

      <div className="mt-8 divide-y divide-line/60 border-t border-line/60">
        {faqs.map((item) => (
          <details key={item.q} className="group py-5">
            <summary className="flex cursor-pointer list-none items-center justify-between text-base font-medium">
              {item.q}
              <span className="text-muted transition-transform group-open:rotate-45">+</span>
            </summary>
            <p className="mt-3 text-sm leading-7 text-ink/65">{item.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
