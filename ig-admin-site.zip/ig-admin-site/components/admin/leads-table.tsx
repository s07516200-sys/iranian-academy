"use client";

import { useMemo, useState } from "react";
import type { Lead, LeadStatus } from "@/types";
import { LeadStatusSelect } from "@/components/admin/lead-status-select";

const STATUSES: LeadStatus[] = ["جدید", "در حال پیگیری", "تکمیل شد", "رد شد"];

export function LeadsTable({ leads }: { leads: Lead[] }) {
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<LeadStatus | "همه">("همه");

  const filtered = useMemo(() => {
    return leads.filter((lead) => {
      const matchesStatus = statusFilter === "همه" || lead.status === statusFilter;
      const q = query.trim();
      const matchesQuery =
        q === "" || lead.name.includes(q) || lead.phone.includes(q) || lead.businessType.includes(q);
      return matchesStatus && matchesQuery;
    });
  }, [leads, query, statusFilter]);

  return (
    <div>
      <div className="flex flex-wrap gap-3">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="جستجو (نام، شماره، نوع کسب‌وکار)"
          className="input max-w-xs"
        />
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as LeadStatus | "همه")}
          className="input w-auto"
        >
          <option value="همه">همه وضعیت‌ها</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {filtered.length === 0 ? (
        <p className="mt-8 text-sm text-muted">لیدی با این فیلتر پیدا نشد.</p>
      ) : (
        <div className="mt-6 overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b border-line/60 text-start text-muted">
                <th className="py-2 pe-4 font-normal">نام</th>
                <th className="py-2 pe-4 font-normal">تماس</th>
                <th className="py-2 pe-4 font-normal">کسب‌وکار</th>
                <th className="py-2 pe-4 font-normal">خدمت درخواستی</th>
                <th className="py-2 pe-4 font-normal">تاریخ</th>
                <th className="py-2 font-normal">وضعیت</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((lead) => (
                <tr key={lead.id} className="border-b border-line/30 align-top">
                  <td className="py-3 pe-4">{lead.name}</td>
                  <td className="py-3 pe-4">
                    <a href={`tel:${lead.phone}`} className="hover:text-gold">
                      {lead.phone}
                    </a>
                    {lead.instagramUsername && (
                      <p className="text-xs text-muted">{lead.instagramUsername}</p>
                    )}
                  </td>
                  <td className="py-3 pe-4">{lead.businessType}</td>
                  <td className="py-3 pe-4">
                    {lead.service}
                    {lead.message && (
                      <p className="mt-1 max-w-xs text-xs text-muted">{lead.message}</p>
                    )}
                  </td>
                  <td className="py-3 pe-4 text-xs text-muted">
                    {new Date(lead.createdAt).toLocaleDateString("fa-IR")}
                  </td>
                  <td className="py-3">
                    <LeadStatusSelect leadId={lead.id} status={lead.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
