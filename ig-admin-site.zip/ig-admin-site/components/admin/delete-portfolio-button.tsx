"use client";

import { useState } from "react";
import { deletePortfolioAction } from "@/app/admin/actions";

export function DeletePortfolioButton({ id, title }: { id: string; title: string }) {
  const [pending, setPending] = useState(false);

  async function handleClick() {
    if (!confirm(`«${title}» حذف شود؟ این عمل قابل بازگشت نیست.`)) return;
    setPending(true);
    try {
      await deletePortfolioAction(id);
    } catch {
      alert("حذف نشد. دوباره تلاش کن.");
      setPending(false);
    }
  }

  return (
    <button
      onClick={handleClick}
      disabled={pending}
      className="text-xs text-red-600 hover:underline disabled:opacity-50"
    >
      {pending ? "..." : "حذف"}
    </button>
  );
}
