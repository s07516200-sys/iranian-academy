"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { savePortfolioAction } from "@/app/admin/actions";
import type { PortfolioItem, Category } from "@/types";

export function PortfolioForm({
  categories,
  initial,
}: {
  categories: Category[];
  initial?: PortfolioItem;
}) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(formData: FormData) {
    setSaving(true);
    setError(null);
    try {
      await savePortfolioAction(formData);
      // ناوبری رو خود کلاینت انجام می‌ده، نه redirect() داخل action —
      // چون این تابع با try/catch صدا زده می‌شه (نه به‌عنوان form action خام)،
      // و redirect() با throw کار می‌کنه که همون try/catch گیرش می‌انداخت.
      router.push("/admin/portfolio");
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "ذخیره نشد.");
      setSaving(false);
    }
  }

  return (
    <form action={handleSubmit} className="max-w-2xl space-y-5">
      {initial && <input type="hidden" name="id" defaultValue={initial.id} />}

      <Field label="عنوان">
        <input name="title" defaultValue={initial?.title} required className="input" />
      </Field>

      <Field label="اسلاگ (لاتین)" hint="مثال: restaurant-sofrehdar">
        <input name="slug" defaultValue={initial?.slug} required className="input" dir="ltr" />
      </Field>

      <Field label="دسته">
        <select name="categoryId" defaultValue={initial?.categoryId} required className="input">
          <option value="" disabled>
            انتخاب کن
          </option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </Field>

      <Field label="نام مشتری (اختیاری)">
        <input name="clientName" defaultValue={initial?.clientName ?? ""} className="input" />
      </Field>

      <Field label="توضیح کوتاه">
        <textarea
          name="description"
          defaultValue={initial?.description}
          required
          rows={2}
          className="input resize-none"
        />
      </Field>

      <Field label="مشکل اولیه (اختیاری)">
        <textarea
          name="problem"
          defaultValue={initial?.problem ?? ""}
          rows={2}
          className="input resize-none"
        />
      </Field>

      <Field label="کارهای انجام‌شده" hint="هر خط یک مورد">
        <textarea
          name="workDoneText"
          defaultValue={initial?.workDone.join("\n") ?? ""}
          rows={4}
          className="input resize-none"
        />
      </Field>

      <Field label="استراتژی محتوا (اختیاری)">
        <textarea
          name="strategy"
          defaultValue={initial?.strategy ?? ""}
          rows={2}
          className="input resize-none"
        />
      </Field>

      <Field label="برچسب‌ها" hint="با کاما جدا کن">
        <input name="tagsText" defaultValue={initial?.tags.join(", ") ?? ""} className="input" />
      </Field>

      <Field label="عکس کاور (URL)" hint="لینک تصویر آپلودشده در Supabase Storage">
        <input name="coverImage" defaultValue={initial?.coverImage ?? ""} className="input" dir="ltr" />
      </Field>

      <Field label="عکس قبل (URL، اختیاری)">
        <input name="beforeImage" defaultValue={initial?.beforeImage ?? ""} className="input" dir="ltr" />
      </Field>

      <Field label="عکس بعد (URL، اختیاری)">
        <input name="afterImage" defaultValue={initial?.afterImage ?? ""} className="input" dir="ltr" />
      </Field>

      <Field label="نتایج (اختیاری)" hint="فقط نتایج واقعی — چیزی رو نساز">
        <textarea
          name="results"
          defaultValue={initial?.results ?? ""}
          rows={2}
          className="input resize-none"
        />
      </Field>

      <div className="flex gap-6">
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="featured" defaultChecked={initial?.featured} />
          ویژه (در صفحه اصلی نشون داده بشه)
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="published" defaultChecked={initial?.published} />
          منتشر شده (قابل مشاهده برای عموم)
        </label>
      </div>

      {error && <p className="text-sm text-red-600">{error}</p>}

      <button
        type="submit"
        disabled={saving}
        className="rounded-full bg-ink px-6 py-3 text-sm font-medium text-paper transition-colors hover:bg-line disabled:cursor-not-allowed disabled:opacity-50"
      >
        {saving ? "در حال ذخیره..." : "ذخیره"}
      </button>
    </form>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm text-ink/70">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}
    </label>
  );
}
