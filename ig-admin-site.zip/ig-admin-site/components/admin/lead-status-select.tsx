"use client";

import { useState } from "react";
import { updateLeadStatusAction } from "@/app/admin/actions";
import type { LeadStatus } from "@/types";

const STATUSES: LeadStatus[] = ["جدید", "در حال پیگیری", "تکمیل شد", "رد شد"];

export function LeadStatusSelect({
  leadId,
  status,
}: {
  leadId: string;
  status: LeadStatus;
}) {
  const [value, setValue] = useState<LeadStatus>(status);
  const [isPending, setIsPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // عمداً controlled (نه defaultValue) و عمداً بدون useTransition:
  // ۱) اگه درخواست fail بشه باید select به مقدار قبلی برگرده — با defaultValue ممکن نبود.
  // ۲) با React 18، startTransition تابع async رو await نمی‌کنه (این رفتار مال React 19ه)،
  //    پس isPending زودتر از اتمام واقعی درخواست false می‌شد.
  async function handleChange(e: React.ChangeEvent<HTMLSelectElement>) {
    const next = e.target.value as LeadStatus;
    const previous = value;
    setValue(next);
    setError(null);
    setIsPending(true);
    try {
      await updateLeadStatusAction(leadId, next);
    } catch {
      setValue(previous);
      setError("ثبت نشد");
    } finally {
      setIsPending(false);
    }
  }

  return (
    <div>
      <select
        value={value}
        disabled={isPending}
        onChange={handleChange}
        className="rounded-full border border-line/60 bg-paper px-3 py-1.5 text-xs disabled:opacity-50"
      >
        {STATUSES.map((s) => (
          <option key={s} value={s}>
            {s}
          </option>
        ))}
      </select>
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}
