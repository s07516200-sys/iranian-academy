import { SITE } from "@/lib/constants";
import type { SiteSettings } from "@/types";

export function PersonJsonLd({ settings }: { settings: SiteSettings }) {
  const data = {
    "@context": "https://schema.org",
    "@type": "ProfessionalService",
    name: `${SITE.brandName} | ${SITE.brandRole}`,
    description:
      "ادمینی، تولید محتوا و مدیریت حرفه‌ای اینستاگرام برای کسب‌وکارهای محلی و آنلاین.",
    areaServed: "IR",
    ...(settings.instagramUrl ? { sameAs: [settings.instagramUrl] } : {}),
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
