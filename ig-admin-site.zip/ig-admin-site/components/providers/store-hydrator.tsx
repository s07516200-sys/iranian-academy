"use client";

import { useEffect } from "react";
import { useSavedStore } from "@/lib/store/saved";

// چون persist با skipHydration:true تنظیم شده، rehydrate باید صریح و فقط
// سمت کلاینت صدا زده بشه — یک‌بار برای کل اپ، نه در هر کامپوننتی که از
// useSavedStore استفاده می‌کنه (که باعث rehydrate تکراری می‌شد).
export function StoreHydrator() {
  useEffect(() => {
    useSavedStore.persist.rehydrate();
  }, []);

  return null;
}
