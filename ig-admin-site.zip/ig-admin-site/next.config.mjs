/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    // ادمین (که ممکنه غیرفنی باشه) آدرس عکس‌ها رو به‌صورت متن آزاد وارد می‌کنه؛
    // اگه فقط *.supabase.co مجاز بود، وارد کردن هر لینک دیگه‌ای (مثلاً از یک
    // سرویس دیگه) باعث کرش کل صفحه کیس‌استادی می‌شد، نه فقط عکس شکسته.
    // چون این یک CMS تک‌ادمینه (نه آپلود عمومی)، اجازه دادن به همه هاست‌های
    // https ریسک قابل‌قبولیه.
    remotePatterns: [{ protocol: "https", hostname: "**" }],
    formats: ["image/avif", "image/webp"],
  },
};

export default nextConfig;
