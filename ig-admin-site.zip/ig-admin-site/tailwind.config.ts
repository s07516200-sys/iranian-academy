import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#171512",       // پس‌زمینه تیره اصلی
        paper: "#F7F4EE",     // پس‌زمینه روشن
        gold: {
          DEFAULT: "#C89A4A",
          soft: "#E4C889",
        },
        moss: {
          DEFAULT: "#5C6B52",
          soft: "#8A9481",
        },
        muted: "#8A8577",
        line: "#2A2722",
      },
      fontFamily: {
        sans: ["var(--font-vazirmatn)", "Tahoma", "sans-serif"],
      },
      borderRadius: {
        card: "14px",
      },
      maxWidth: {
        prose: "68ch",
      },
    },
  },
  plugins: [],
};

export default config;
