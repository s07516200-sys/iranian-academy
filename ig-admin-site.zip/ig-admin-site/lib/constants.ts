import { SERVICES } from "@/lib/data/services";

// این مقادیر ساختاری‌ان (نه محتوایی) — نام برند، ناوبری، لیست خدمات.
// شماره واتساپ/لینک اینستاگرام/متن هیرو/آمار از site_settings (پنل ادمین) میان،
// نه از اینجا؛ ببین lib/data/settings.ts.
export const SITE = {
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://example.com",
  brandName: "سعید",
  brandRole: "ادمین اینستاگرام",
  // منبع واحد: عناوین از lib/data/services.ts می‌آد تا با کارت‌های خدمات sync بمونه
  services: SERVICES.map((s) => s.title),
  nav: [
    { label: "خانه", href: "/" },
    { label: "خدمات", href: "/services" },
    { label: "نمونه‌کارها", href: "/portfolio" },
    { label: "نتایج", href: "/#natayej" },
    { label: "درباره من", href: "/about" },
    { label: "تماس با من", href: "/contact" },
  ],
} as const;

export function whatsappLink(number: string, message?: string) {
  const base = `https://wa.me/${number}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}
