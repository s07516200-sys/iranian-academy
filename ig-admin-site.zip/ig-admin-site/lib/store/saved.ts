"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

type SavedState = {
  anonymousId: string;
  savedIds: string[];
  hasHydrated: boolean;
  toggle: (portfolioId: string) => void;
  isSaved: (portfolioId: string) => boolean;
  setHasHydrated: (v: boolean) => void;
};

function generateId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `anon-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

// این استور فعلاً فقط localStorage رو منبع حقیقت می‌دونه.
// وقتی حساب کاربری اضافه بشه، همین anonymousId برای merge با user_id
// در جدول saved_items استفاده می‌شه (طبق طراحی فاز ۰).
export const useSavedStore = create<SavedState>()(
  persist(
    (set, get) => ({
      anonymousId: generateId(),
      savedIds: [],
      hasHydrated: false,
      toggle: (portfolioId) => {
        const current = get().savedIds;
        const next = current.includes(portfolioId)
          ? current.filter((id) => id !== portfolioId)
          : [...current, portfolioId];
        set({ savedIds: next });
      },
      isSaved: (portfolioId) => get().savedIds.includes(portfolioId),
      setHasHydrated: (v) => set({ hasHydrated: v }),
    }),
    {
      name: "ig-admin-saved",
      // صریحاً rehydrate خودکار رو غیرفعال می‌کنیم؛ چون این استور در SSR هم
      // evaluate می‌شه (کامپوننت کلاینته ولی برای HTML اولیه روی سرور رندر می‌شه)
      // و localStorage در Node وجود نداره. rehydrate واقعی از <StoreHydrator/>
      // در app/layout.tsx و فقط سمت کلاینت صدا زده می‌شه.
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    }
  )
);
