import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

// از این کلاینت در Server Component / Route Handler استفاده کن.
// این کلاینت با anon key کار می‌کنه، یعنی محدود به RLS policyهاست:
// می‌تونه هرچی رو که برای anon مجازه بخونه/بنویسه (مثلاً insert در جدول leads).
// برای عملیاتی که باید RLS رو دور بزنن (مثل CRUD پنل ادمین روی هر رکورد،
// صرف‌نظر از published بودنش)، باید از lib/supabase/admin.ts (service role) استفاده کرد،
// و service role key هرگز نباید به کلاینت مرورگر برسه.
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // در Server Component خواندنی صدا زده شده — قابل چشم‌پوشی است
          }
        },
      },
    }
  );
}
