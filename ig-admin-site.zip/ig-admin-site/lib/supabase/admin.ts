import { createClient as createSupabaseClient } from "@supabase/supabase-js";

// فقط در Route Handler ها و کد سمت سرور import بشه.
// SUPABASE_SERVICE_ROLE_KEY هرگز نباید NEXT_PUBLIC باشه یا به کلاینت برسه.
export function createAdminClient() {
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}
