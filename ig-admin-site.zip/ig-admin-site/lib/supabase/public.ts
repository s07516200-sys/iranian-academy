import { createClient as createSupabaseClient } from "@supabase/supabase-js";

// برای خوندن داده‌های عمومی (پورتفولیوی published، دسته‌ها، site_settings).
// عمداً از createServerClient با cookies() استفاده نمی‌کنیم: این داده‌ها به
// session کاربر ربطی ندارن (RLS با anon key و using(true)/published=true
// مجازشون کرده)، پس با یک کلاینت stateless می‌خونیمشون تا صفحات همچنان
// قابل static render / ISR باشن و به cookies() (که رندر رو dynamic می‌کنه) گیر نکنن.
export function createPublicClient() {
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
