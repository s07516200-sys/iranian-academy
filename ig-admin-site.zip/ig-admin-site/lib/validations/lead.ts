import { z } from "zod";

export const leadSchema = z.object({
  name: z.string().trim().min(2, "نام باید حداقل ۲ حرف باشد").max(80),
  phone: z
    .string()
    .trim()
    .regex(/^09\d{9}$/, "شماره موبایل معتبر نیست (مثال: 09121234567)"),
  businessType: z.string().trim().min(2, "نوع کسب‌وکار را وارد کنید").max(80),
  instagramUsername: z.string().trim().max(60).optional().or(z.literal("")),
  service: z.string().trim().min(2, "نوع خدمات موردنیاز را انتخاب کنید"),
  message: z.string().trim().max(1000).optional().or(z.literal("")),
  // honeypot: باید همیشه خالی بمونه؛ ربات‌ها معمولاً پرش می‌کنن
  website: z.string().max(0).optional().or(z.literal("")),
});

export type LeadInput = z.infer<typeof leadSchema>;
