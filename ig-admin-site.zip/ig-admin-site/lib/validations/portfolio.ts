import { z } from "zod";

// اسلاگ لاتین/انگلیسی — طبق تصمیم فاز ۳، برای جلوگیری از انکود شدن URL فارسی
const slugPattern = /^[a-z0-9]+(-[a-z0-9]+)*$/;

export const portfolioFormSchema = z.object({
  title: z.string().trim().min(2, "عنوان را وارد کنید").max(150),
  slug: z
    .string()
    .trim()
    .toLowerCase()
    .regex(slugPattern, "اسلاگ باید لاتین باشه، فقط حروف کوچک/عدد/خط تیره (مثال: restaurant-sofrehdar)"),
  categoryId: z.string().trim().min(1, "دسته را انتخاب کنید"),
  clientName: z.string().trim().max(80).optional().or(z.literal("")),
  description: z.string().trim().min(1, "توضیح کوتاه را وارد کنید").max(500),
  problem: z.string().trim().max(1000).optional().or(z.literal("")),
  // هر خط یک آیتم؛ خطوط خالی حذف می‌شن
  workDoneText: z.string().optional().or(z.literal("")),
  strategy: z.string().trim().max(1000).optional().or(z.literal("")),
  // با کاما جدا می‌شن
  tagsText: z.string().optional().or(z.literal("")),
  coverImage: z.string().trim().max(500).optional().or(z.literal("")),
  beforeImage: z.string().trim().max(500).optional().or(z.literal("")),
  afterImage: z.string().trim().max(500).optional().or(z.literal("")),
  results: z.string().trim().max(1000).optional().or(z.literal("")),
  featured: z.boolean().default(false),
  published: z.boolean().default(false),
});

export type PortfolioFormInput = z.infer<typeof portfolioFormSchema>;

export function linesToArray(text: string | undefined): string[] {
  if (!text) return [];
  return text
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
}

export function commaToArray(text: string | undefined): string[] {
  if (!text) return [];
  return text
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean);
}
