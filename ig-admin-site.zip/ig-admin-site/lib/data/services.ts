export type ServiceItem = {
  slug: string;
  icon: "grid" | "pen" | "clapper" | "image" | "calendar" | "trend" | "heart" | "chart";
  title: string;
  shortDesc: string;
  longDesc: string;
};

export const SERVICES: ServiceItem[] = [
  {
    slug: "modiriat-page",
    icon: "grid",
    title: "مدیریت کامل پیج",
    shortDesc: "ادمینی روزانه پیج شامل پاسخگویی و برنامه‌ریزی انتشار.",
    longDesc:
      "پیج شما هر روز رصد و مدیریت می‌شه: پاسخ به دایرکت و کامنت‌ها، زمان‌بندی انتشار محتوا، و هماهنگی کلی با استراتژی تعیین‌شده.",
  },
  {
    slug: "tolid-mohtava",
    icon: "pen",
    title: "تولید محتوای اینستاگرام",
    shortDesc: "نگارش کپشن و ایده‌پردازی محتوا متناسب با کسب‌وکار شما.",
    longDesc:
      "ایده‌پردازی، نگارش کپشن و ساختاردهی محتوا بر اساس لحن برند شما و چیزی که برای مخاطب هدفتون جذابه.",
  },
  {
    slug: "reels",
    icon: "clapper",
    title: "ساخت و تدوین Reels",
    shortDesc: "تولید و تدوین ریلزهایی که بازدید و تعامل می‌گیرن.",
    longDesc:
      "از ایده تا تدوین نهایی؛ ریلزهایی که با فرمت‌های پربازدید روز هماهنگ‌ان و همزمان با هویت برند شما جور در میان.",
  },
  {
    slug: "post-story",
    icon: "image",
    title: "طراحی پست و استوری",
    shortDesc: "طراحی بصری هماهنگ با هویت برند شما.",
    longDesc: "طراحی گرافیکی پست و استوری با رعایت یکدستی بصری در کل پیج.",
  },
  {
    slug: "taghvim-mohtava",
    icon: "calendar",
    title: "تقویم محتوایی",
    shortDesc: "برنامه‌ریزی منظم انتشار برای ثبات پیج.",
    longDesc: "تدوین تقویم محتوایی ماهانه تا انتشار پیج منظم و قابل پیش‌بینی باشه.",
  },
  {
    slug: "strategy-roshd",
    icon: "trend",
    title: "استراتژی رشد پیج",
    shortDesc: "برنامه رشد متناسب با نوع کسب‌وکار و مخاطب هدف.",
    longDesc: "تحلیل بازار و رقبا برای تدوین مسیر رشد واقع‌بینانه پیج شما.",
  },
  {
    slug: "afzayesh-taamol",
    icon: "heart",
    title: "افزایش تعامل",
    shortDesc: "تکنیک‌های واقعی برای بالا بردن نرخ تعامل مخاطبان.",
    longDesc: "استفاده از فرمت‌های تعامل‌محور (نظرسنجی، سوال، چالش) متناسب با مخاطب شما.",
  },
  {
    slug: "gozaresh",
    icon: "chart",
    title: "تحلیل و گزارش عملکرد",
    shortDesc: "گزارش دوره‌ای شفاف از عملکرد پیج.",
    longDesc: "گزارش دوره‌ای شامل رشد فالوور، تعامل و عملکرد محتوا برای تصمیم‌گیری بهتر.",
  },
];
