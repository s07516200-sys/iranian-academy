import { createPublicClient } from "@/lib/supabase/public";
import type { Category } from "@/types";

// دسته‌ها حالا مستقیم از جدول categories در Supabase خونده می‌شن (نه لیست محلی)،
// چون category_id در portfolio_items یک uuid واقعیه که فقط با query قابل resolve کردنه.
export async function getCategories(): Promise<Category[]> {
  const supabase = createPublicClient();
  const { data, error } = await supabase
    .from("categories")
    .select("*")
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("getCategories error:", error.message);
    return [];
  }

  return data as Category[];
}
