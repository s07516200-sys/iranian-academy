import { createPublicClient } from "@/lib/supabase/public";
import { createAdminClient } from "@/lib/supabase/admin";
import type { SiteSettings } from "@/types";

const DEFAULTS: SiteSettings = {
  whatsappNumber: "",
  instagramUrl: "",
  heroTitle: "پیج اینستاگرامت رو حرفه‌ای مدیریت کن",
  heroSubtitle:
    "ادمینی، تولید محتوا و مدیریت حرفه‌ای اینستاگرام برای کسب‌وکارهایی که می‌خوان بهتر دیده بشن و مشتری بیشتری جذب کنن.",
  statsProjects: null,
  statsContent: null,
  statsPages: null,
  statsYears: null,
};

const KEY_MAP: Record<keyof SiteSettings, string> = {
  whatsappNumber: "whatsapp_number",
  instagramUrl: "instagram_url",
  heroTitle: "hero_title",
  heroSubtitle: "hero_subtitle",
  statsProjects: "stats_projects",
  statsContent: "stats_content",
  statsPages: "stats_pages",
  statsYears: "stats_years",
};

// عمومی: هر بازدیدکننده باید بتونه اینا رو بخونه (متن هیرو، شماره واتساپ و...)
export async function getSiteSettings(): Promise<SiteSettings> {
  const supabase = createPublicClient();
  const { data, error } = await supabase.from("site_settings").select("key, value");

  if (error || !data) return DEFAULTS;

  const rows = new Map(data.map((r) => [r.key as string, r.value as string]));
  const result: SiteSettings = { ...DEFAULTS };

  for (const [field, dbKey] of Object.entries(KEY_MAP) as [keyof SiteSettings, string][]) {
    const value = rows.get(dbKey);
    if (value) (result[field] as string | null) = value;
  }

  return result;
}

// ادمین: فقط از app/admin/** بعد از چک session صدا زده بشه
export async function updateSiteSettings(partial: Partial<SiteSettings>) {
  const admin = createAdminClient();

  const rows = Object.entries(partial).map(([field, value]) => ({
    key: KEY_MAP[field as keyof SiteSettings],
    value: value ?? "",
  }));

  const { error } = await admin.from("site_settings").upsert(rows, { onConflict: "key" });
  if (error) throw new Error(error.message);
}
