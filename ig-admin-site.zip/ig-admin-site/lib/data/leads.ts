import { createAdminClient } from "@/lib/supabase/admin";
import type { Lead, LeadStatus } from "@/types";

type LeadRow = {
  id: string;
  name: string;
  phone: string;
  business_type: string;
  instagram_username: string | null;
  service: string;
  message: string | null;
  status: LeadStatus;
  created_at: string;
};

function mapLead(row: LeadRow): Lead {
  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    businessType: row.business_type,
    instagramUsername: row.instagram_username,
    service: row.service,
    message: row.message,
    status: row.status,
    createdAt: row.created_at,
  };
}

// این تابع فقط باید از کد سمت سرور که قبلاً session ادمین رو چک کرده صدا زده بشه
// (app/admin/**) — خودش هیچ چک احراز هویتی نداره چون service role هست و RLS رو دور می‌زنه.
export async function getLeads(): Promise<Lead[]> {
  const admin = createAdminClient();
  const { data, error } = await admin
    .from("leads")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("getLeads error:", error.message);
    return [];
  }

  return (data as LeadRow[]).map(mapLead);
}

export async function getLeadCounts(): Promise<Record<LeadStatus, number>> {
  const leads = await getLeads();
  const counts: Record<LeadStatus, number> = {
    جدید: 0,
    "در حال پیگیری": 0,
    "تکمیل شد": 0,
    "رد شد": 0,
  };
  for (const lead of leads) counts[lead.status]++;
  return counts;
}
