import { createPublicClient } from "@/lib/supabase/public";
import { createAdminClient } from "@/lib/supabase/admin";
import type { PortfolioItem } from "@/types";

export const DEMO_SLUG = "namoone-ghaleb";

// این آیتم صرفاً برای تست قالب کیس‌استادیه — به هیچ ردیف واقعی در DB وصل نیست،
// هیچ‌وقت در لیست عمومی /portfolio نشون داده نمی‌شه و در sitemap هم نمیاد.
export const DEMO_PORTFOLIO_ITEM: PortfolioItem = {
  id: "demo",
  title: "نمونه قالب کیس‌استادی",
  slug: DEMO_SLUG,
  categoryId: "",
  categoryName: "رستوران",
  categorySlug: "restaurant",
  clientName: "[نام مشتری]",
  description: "این یک نمونهٔ ساختاری برای پیش‌نمایش قالب کیس‌استادیه، نه یک پروژه واقعی.",
  coverImage: "",
  beforeImage: null,
  afterImage: null,
  problem: "[توضیح مشکل اولیه پیج مشتری — بعد از افزودن پروژه واقعی جایگزین بشه]",
  workDone: [
    "[کار انجام‌شده ۱ — مثلاً تدوین تقویم محتوایی]",
    "[کار انجام‌شده ۲ — مثلاً تولید ریلز هفتگی]",
    "[کار انجام‌شده ۳ — مثلاً بازطراحی هایلایت‌ها]",
  ],
  strategy: "[خلاصه استراتژی محتوایی به‌کاررفته]",
  tags: ["نمونه", "قالب"],
  results: null,
  featured: false,
  published: false,
  isDemo: true,
  createdAt: new Date().toISOString(),
};

type PortfolioRow = {
  id: string;
  title: string;
  slug: string;
  category_id: string | null;
  client_name: string | null;
  description: string;
  problem: string | null;
  work_done: string[] | null;
  strategy: string | null;
  cover_image: string | null;
  before_image: string | null;
  after_image: string | null;
  results: string | null;
  tags: string[] | null;
  featured: boolean;
  published: boolean;
  created_at: string;
  categories: { name: string; slug: string } | null;
};

function mapRow(row: PortfolioRow): PortfolioItem {
  return {
    id: row.id,
    title: row.title,
    slug: row.slug,
    categoryId: row.category_id ?? "",
    categoryName: row.categories?.name ?? "سایر",
    categorySlug: row.categories?.slug ?? "other",
    clientName: row.client_name,
    description: row.description,
    coverImage: row.cover_image ?? "",
    beforeImage: row.before_image,
    afterImage: row.after_image,
    problem: row.problem,
    workDone: row.work_done ?? [],
    strategy: row.strategy,
    tags: row.tags ?? [],
    results: row.results,
    featured: row.featured,
    published: row.published,
    createdAt: row.created_at,
  };
}

const SELECT_WITH_CATEGORY = "*, categories(name, slug)";

// ---------------------------------------------------------------
// عمومی (anon، فقط published=true — طبق RLS در supabase/schema.sql)
// ---------------------------------------------------------------

export async function getPublishedItems(): Promise<PortfolioItem[]> {
  const supabase = createPublicClient();
  const { data, error } = await supabase
    .from("portfolio_items")
    .select(SELECT_WITH_CATEGORY)
    .eq("published", true)
    .order("featured", { ascending: false })
    .order("created_at", { ascending: false });

  if (error) {
    console.error("getPublishedItems error:", error.message);
    return [];
  }

  return (data as unknown as PortfolioRow[]).map(mapRow);
}

export async function getFeaturedItems(limit = 3): Promise<PortfolioItem[]> {
  const items = await getPublishedItems();
  return items.filter((item) => item.featured).slice(0, limit);
}

export async function getPortfolioItemBySlug(slug: string): Promise<PortfolioItem | null> {
  if (slug === DEMO_SLUG) return DEMO_PORTFOLIO_ITEM;

  const supabase = createPublicClient();
  const { data, error } = await supabase
    .from("portfolio_items")
    .select(SELECT_WITH_CATEGORY)
    .eq("slug", slug)
    .eq("published", true)
    .maybeSingle();

  if (error || !data) return null;
  return mapRow(data as unknown as PortfolioRow);
}

/** برای generateStaticParams / sitemap — فقط اسلاگ پروژه‌های منتشرشده */
export async function getPublishedSlugs(): Promise<string[]> {
  const supabase = createPublicClient();
  const { data, error } = await supabase
    .from("portfolio_items")
    .select("slug")
    .eq("published", true);

  if (error) return [];
  return (data ?? []).map((row) => row.slug as string);
}

// ---------------------------------------------------------------
// ادمین (service role — همه رکوردها صرف‌نظر از published؛ فقط از
// app/admin/** صدا زده بشه، بعد از چک session)
// ---------------------------------------------------------------

export async function getAllPortfolioAdmin(): Promise<PortfolioItem[]> {
  const admin = createAdminClient();
  const { data, error } = await admin
    .from("portfolio_items")
    .select(SELECT_WITH_CATEGORY)
    .order("created_at", { ascending: false });

  if (error) {
    console.error("getAllPortfolioAdmin error:", error.message);
    return [];
  }

  return (data as unknown as PortfolioRow[]).map(mapRow);
}

export async function getPortfolioByIdAdmin(id: string): Promise<PortfolioItem | null> {
  const admin = createAdminClient();
  const { data, error } = await admin
    .from("portfolio_items")
    .select(SELECT_WITH_CATEGORY)
    .eq("id", id)
    .maybeSingle();

  if (error || !data) return null;
  return mapRow(data as unknown as PortfolioRow);
}

export type PortfolioInput = {
  title: string;
  slug: string;
  categoryId: string;
  clientName: string;
  description: string;
  problem: string;
  workDone: string[];
  strategy: string;
  tags: string[];
  coverImage: string;
  beforeImage: string;
  afterImage: string;
  results: string;
  featured: boolean;
  published: boolean;
};

function toRow(input: PortfolioInput) {
  return {
    title: input.title,
    slug: input.slug,
    category_id: input.categoryId || null,
    client_name: input.clientName || null,
    description: input.description,
    problem: input.problem || null,
    work_done: input.workDone,
    strategy: input.strategy || null,
    tags: input.tags,
    cover_image: input.coverImage || null,
    before_image: input.beforeImage || null,
    after_image: input.afterImage || null,
    results: input.results || null,
    featured: input.featured,
    published: input.published,
  };
}

export async function createPortfolioItem(input: PortfolioInput) {
  const admin = createAdminClient();
  const { data, error } = await admin
    .from("portfolio_items")
    .insert(toRow(input))
    .select("id")
    .single();

  if (error) throw new Error(error.message);
  return data.id as string;
}

export async function updatePortfolioItem(id: string, input: PortfolioInput) {
  const admin = createAdminClient();
  const { error } = await admin
    .from("portfolio_items")
    .update({ ...toRow(input), updated_at: new Date().toISOString() })
    .eq("id", id);

  if (error) throw new Error(error.message);
}

export async function deletePortfolioItem(id: string) {
  const admin = createAdminClient();
  const { error } = await admin.from("portfolio_items").delete().eq("id", id);
  if (error) throw new Error(error.message);
}
